"""
Runs sql/01..06 on SQLite (portable ANSI SQL; works in PostgreSQL with minor DDL changes).
Each numbered file is one SELECT, materialised as a table named after the file and exported to CSV.

    python src/run_sql_pipeline.py --data data --out outputs/tables
"""
import argparse, glob, os, re, sqlite3, time
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--sql", default="sql")
    ap.add_argument("--out", default="outputs/tables")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    con = sqlite3.connect(":memory:")
    for name in ("users", "usage_14d", "subscriptions", "invoices"):
        pd.read_csv(os.path.join(args.data, f"{name}.csv")).to_sql(name, con, index=False)
    con.execute("CREATE INDEX ix_inv_user ON invoices(user_id)")
    for path in sorted(glob.glob(os.path.join(args.sql, "[0-9]*.sql"))):
        name = re.sub(r"^\d+_", "", os.path.splitext(os.path.basename(path))[0])
        t = time.time()
        con.execute(f"CREATE TABLE {name} AS {open(path).read().strip().rstrip(';')}")
        df = pd.read_sql(f"SELECT * FROM {name}", con)
        df.to_csv(os.path.join(args.out, f"{name}.csv"), index=False)
        print(f"{name:<20} rows={len(df):>8,}  {time.time()-t:.1f}s")


if __name__ == "__main__":
    main()
