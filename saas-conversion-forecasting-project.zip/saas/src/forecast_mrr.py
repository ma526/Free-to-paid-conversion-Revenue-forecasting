"""
Monthly recurring revenue (MRR) forecasting with rolling-origin backtesting, plus scenarios.

Models (all run in this repo's build):
  naive           last value carried forward
  drift           last value + average historical monthly change
  holt_damped     damped-trend exponential smoothing (own implementation, scipy optimiser)
  bottom_up       driver model: forecast NEW MRR (damped Holt) and apply recent expansion and churn rates
Optional (only if the package is installed locally; NOT run in the build environment):
  sarima          statsmodels SARIMAX(1,1,1) with drift
  prophet         Prophet (additive trend; yearly seasonality disabled, only 42 months of history)

Backtest : origins at months 24..36, forecast horizons 1..6, scored by MAPE / MAE
Selection: lowest mean backtest MAPE; interval = forecast * exp(+/- 1.28 * sd of backtest log-errors at that horizon)
           (an approximate 80% interval; only 13 origins, so treat as indicative)

    python src/forecast_mrr.py --tables outputs/tables --figures outputs/figures
"""
import argparse
import os
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize

warnings.filterwarnings("ignore")
HORIZON = 6
ORIGINS = list(range(24, 37))
Z80 = 1.2816
COLORS = {"history": "#7A8499", "forecast": "#5B6CFF", "alt": "#16A085", "bad": "#C0392B"}


# ---------------------------------------------------------------- Holt damped
def _holt_run(y, alpha, beta, phi):
    l, b = y[0], (y[min(3, len(y) - 1)] - y[0]) / max(min(3, len(y) - 1), 1)
    sse = 0.0
    for t in range(1, len(y)):
        f = l + phi * b
        sse += (y[t] - f) ** 2
        l_new = alpha * y[t] + (1 - alpha) * f
        b = beta * (l_new - l) + (1 - beta) * phi * b
        l = l_new
    return sse, l, b


def holt_damped(y, h):
    y = np.asarray(y, float)
    best = None
    for x0 in [(0.5, 0.2, 0.9), (0.2, 0.05, 0.95), (0.8, 0.5, 0.85)]:
        r = minimize(lambda p: _holt_run(y, *p)[0], x0, bounds=[(0.01, 0.99), (0.01, 0.99), (0.80, 0.995)],
                     method="L-BFGS-B")
        if best is None or r.fun < best.fun:
            best = r
    a, b_, phi = best.x
    _, l, b = _holt_run(y, a, b_, phi)
    steps = np.cumsum(phi ** np.arange(1, h + 1))
    return l + steps * b


def f_naive(y, h):
    return np.repeat(y[-1], h)


def f_drift(y, h):
    return y[-1] + (y[-1] - y[0]) / (len(y) - 1) * np.arange(1, h + 1)


def make_bottom_up(bridge):
    """bridge: dataframe indexed by month_idx with new_mrr, expansion_mrr, churned_mrr, mrr."""
    def f(y, h):
        n = len(y)                                  # months 0..n-1 are known
        hist = bridge.iloc[:n]
        new_fc = np.maximum(holt_damped(hist.new_mrr.to_numpy(float), h), 0)
        prev = hist.mrr.shift(1)
        exp_rate = (hist.expansion_mrr / prev).iloc[-6:].mean()
        churn_rate = (hist.churned_mrr / prev).iloc[-6:].mean()
        out, cur = [], float(y[-1])
        for k in range(h):
            cur = cur * (1 + exp_rate - churn_rate) + new_fc[k]
            out.append(cur)
        return np.array(out)
    f.parts = lambda n, h: None
    return f


def try_optional_models():
    models = {}
    try:
        from statsmodels.tsa.statespace.sarimax import SARIMAX

        def f_sarima(y, h):
            res = SARIMAX(np.asarray(y, float), order=(1, 1, 1), trend="t").fit(disp=False)
            return np.asarray(res.forecast(h))
        models["sarima"] = f_sarima
    except Exception:
        pass
    try:
        from prophet import Prophet

        def f_prophet(y, h):
            ds = pd.date_range("2023-01-01", periods=len(y), freq="MS")
            m = Prophet(yearly_seasonality=False, weekly_seasonality=False, daily_seasonality=False)
            m.fit(pd.DataFrame({"ds": ds, "y": np.asarray(y, float)}))
            fut = m.make_future_dataframe(periods=h, freq="MS")
            return m.predict(fut).yhat.to_numpy()[-h:]
        models["prophet"] = f_prophet
    except Exception:
        pass
    return models


# ---------------------------------------------------------------- scenarios
def scenario_path(bridge, h, conv_mult=1.0, churn_mult=1.0, exp_mult=1.0):
    hist = bridge
    new_fc = np.maximum(holt_damped(hist.new_mrr.to_numpy(float), h), 0) * conv_mult
    prev = hist.mrr.shift(1)
    exp_rate = (hist.expansion_mrr / prev).iloc[-6:].mean() * exp_mult
    churn_rate = (hist.churned_mrr / prev).iloc[-6:].mean() * churn_mult
    cur, out = float(hist.mrr.iloc[-1]), []
    for k in range(h):
        cur = cur * (1 + exp_rate - churn_rate) + new_fc[k]
        out.append(cur)
    return np.array(out), exp_rate, churn_rate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tables", default="outputs/tables")
    ap.add_argument("--figures", default="outputs/figures")
    args = ap.parse_args()
    os.makedirs(args.figures, exist_ok=True)

    bridge = pd.read_csv(os.path.join(args.tables, "mrr_movements.csv")).sort_values("month_idx").reset_index(drop=True)
    y = bridge.mrr.to_numpy(float)
    n = len(y)
    assert n == 42 and (bridge.month_idx.diff().dropna() == 1).all()
    # reconciliation: the SQL bridge must explain every change in MRR
    recon = (bridge.mrr.shift(1) + bridge.new_mrr + bridge.expansion_mrr - bridge.churned_mrr - bridge.mrr).iloc[1:]
    print(f"MRR bridge reconciliation, max abs error = ${recon.abs().max():.2f}")

    models = {"naive": f_naive, "drift": f_drift, "holt_damped": holt_damped, "bottom_up": make_bottom_up(bridge)}
    models.update(try_optional_models())
    print("models run:", list(models), "\n")

    # ---------------- rolling-origin backtest
    rows = []
    for name, fn in models.items():
        for o in ORIGINS:
            fc = fn(y[:o], HORIZON)
            for h in range(1, HORIZON + 1):
                a = y[o + h - 1]
                rows.append({"model": name, "origin": o, "horizon": h, "actual": a, "forecast": float(fc[h - 1])})
    bt = pd.DataFrame(rows)
    bt["abs_err"] = (bt.actual - bt.forecast).abs()
    bt["ape"] = bt.abs_err / bt.actual
    bt["log_err"] = np.log(bt.actual / bt.forecast)
    bt.to_csv(os.path.join(args.tables, "forecast_backtest_detail.csv"), index=False)

    summ = bt.groupby("model").agg(mape=("ape", "mean"), mae=("abs_err", "mean")).reset_index()
    h_tbl = bt.pivot_table(index="model", columns="horizon", values="ape").add_prefix("mape_h").reset_index()
    final_hold = bt[bt.origin == 36].groupby("model").agg(holdout_mape=("ape", "mean")).reset_index()
    summ = summ.merge(h_tbl, on="model").merge(final_hold, on="model").sort_values("mape")
    summ.to_csv(os.path.join(args.tables, "forecast_backtest_summary.csv"), index=False)
    print("BACKTEST (origins 24-36, horizons 1-6)\n", summ.round(4).to_string(index=False), "\n")

    best = summ.iloc[0].model
    print("selected model:", best)

    # ---------------- final forecast with intervals
    fc = models[best](y, HORIZON)
    sd = bt[bt.model == best].groupby("horizon").log_err.std().to_numpy()
    sd = np.maximum.accumulate(sd)                                  # intervals should not narrow with horizon
    dates = pd.date_range("2026-07-01", periods=HORIZON, freq="MS")
    fdf = pd.DataFrame({"month": dates.strftime("%Y-%m"), "month_idx": np.arange(n, n + HORIZON),
                        "model": best, "forecast_mrr": fc,
                        "lower_80": fc * np.exp(-Z80 * sd), "upper_80": fc * np.exp(Z80 * sd)})
    # also store every model's point forecast so Power BI can compare
    allfc = pd.DataFrame({"month": dates.strftime("%Y-%m")})
    for name, fn in models.items():
        allfc[name] = fn(y, HORIZON)
    allfc.to_csv(os.path.join(args.tables, "forecast_all_models.csv"), index=False)
    fdf.to_csv(os.path.join(args.tables, "mrr_forecast.csv"), index=False)
    print("\nFORECAST Jul-Dec 2026\n", fdf.round(0).to_string(index=False), "\n")

    # ---------------- scenarios (bottom-up driver model)
    base, er, cr = scenario_path(bridge, HORIZON)
    scen = {"Baseline": (1.0, 1.0, 1.0), "Conversion +10%": (1.10, 1.0, 1.0), "Churn -10%": (1.0, 0.90, 1.0),
            "Conversion +10% and churn -10%": (1.10, 0.90, 1.0), "Churn +15% (downside)": (1.0, 1.15, 1.0)}
    srows = []
    for sname, (cm, chm, em) in scen.items():
        path, _, _ = scenario_path(bridge, HORIZON, cm, chm, em)
        srows.append({"scenario": sname, "dec_2026_mrr": path[-1], "vs_baseline": path[-1] - base[-1],
                      "vs_baseline_pct": path[-1] / base[-1] - 1,
                      "six_month_revenue": path.sum(), "six_month_rev_vs_baseline": path.sum() - base.sum()})
    sc = pd.DataFrame(srows)
    sc.to_csv(os.path.join(args.tables, "scenarios.csv"), index=False)
    print(f"Bottom-up drivers: monthly expansion {er:.2%}, monthly MRR churn {cr:.2%} (trailing 6 months)")
    print(sc.round(3).to_string(index=False), "\n")

    # ---------------- retention KPIs
    k = bridge.copy()
    prev = k.mrr.shift(1)
    k["gross_mrr_churn_rate"] = k.churned_mrr / prev
    k["expansion_rate"] = k.expansion_mrr / prev
    k["nrr_monthly"] = (prev + k.expansion_mrr - k.churned_mrr) / prev
    k["mrr_growth"] = k.mrr / prev - 1
    k.to_csv(os.path.join(args.tables, "revenue_kpis.csv"), index=False)
    last6 = k.iloc[-6:]
    print(f"Last-6-month averages: gross MRR churn {last6.gross_mrr_churn_rate.mean():.2%}/mo, "
          f"expansion {last6.expansion_rate.mean():.2%}/mo, NRR {last6.nrr_monthly.mean():.2%}/mo "
          f"(annualised {last6.nrr_monthly.mean()**12:.1%}), MoM growth {last6.mrr_growth.mean():.2%}")

    co = pd.read_csv(os.path.join(args.tables, "cohort_retention.csv"))
    start = co[co.months_since_start == 0].set_index("cohort_idx").active_customers
    co["cohort_size"] = co.cohort_idx.map(start)
    pooled = []
    for m in range(0, 25):
        elig = co[co.cohort_idx <= 41 - m]
        at_m = elig[elig.months_since_start == m]
        base_n = start.loc[elig.cohort_idx.unique()].sum()
        pooled.append({"months_since_start": m, "logo_retention": at_m.active_customers.sum() / base_n,
                       "revenue_retention": at_m.cohort_mrr.sum() /
                       co[(co.months_since_start == 0) & (co.cohort_idx.isin(elig.cohort_idx.unique()))].cohort_mrr.sum()})
    pooled = pd.DataFrame(pooled)
    pooled.to_csv(os.path.join(args.tables, "cohort_retention_curve.csv"), index=False)
    print("\nPooled cohort retention at months 1/3/6/12/24:\n",
          pooled[pooled.months_since_start.isin([1, 3, 6, 12, 24])].round(3).to_string(index=False))

    make_figures(args.figures, bridge, bt, summ, fdf, best, sc, pooled)
    print("\nSaved tables and figures.")


def make_figures(fdir, bridge, bt, summ, fdf, best, sc, pooled):
    months = pd.date_range("2023-01-01", periods=len(bridge), freq="MS")
    plt.figure(figsize=(8, 4.2))
    plt.plot(months, bridge.mrr / 1000, color=COLORS["history"], lw=2, label="actual MRR")
    fm = pd.to_datetime(fdf.month + "-01")
    plt.plot(fm, fdf.forecast_mrr / 1000, color=COLORS["forecast"], lw=2, label=f"forecast ({best})")
    plt.fill_between(fm, fdf.lower_80 / 1000, fdf.upper_80 / 1000, color=COLORS["forecast"], alpha=0.2, label="~80% interval")
    plt.ylabel("MRR, $ thousands"); plt.title("Monthly recurring revenue: history and 6-month forecast")
    plt.legend(); plt.tight_layout(); plt.savefig(os.path.join(fdir, "mrr_forecast.png"), dpi=150); plt.close()

    plt.figure(figsize=(6.5, 3.8))
    s = summ.sort_values("mape")
    plt.barh(s.model, s.mape * 100, color=[COLORS["forecast"] if m == best else COLORS["history"] for m in s.model])
    plt.xlabel("Backtest MAPE, % (13 origins x 6 horizons)"); plt.title("Forecast model comparison")
    plt.gca().invert_yaxis(); plt.tight_layout(); plt.savefig(os.path.join(fdir, "backtest_mape.png"), dpi=150); plt.close()

    plt.figure(figsize=(8, 4))
    plt.bar(months, bridge.new_mrr / 1000, color=COLORS["forecast"], label="new")
    plt.bar(months, bridge.expansion_mrr / 1000, bottom=bridge.new_mrr / 1000, color=COLORS["alt"], label="expansion")
    plt.bar(months, -bridge.churned_mrr / 1000, color=COLORS["bad"], label="churned")
    plt.axhline(0, color="k", lw=0.8); plt.ylabel("MRR movement, $ thousands"); plt.title("MRR bridge by month")
    plt.legend(ncol=3); plt.tight_layout(); plt.savefig(os.path.join(fdir, "mrr_bridge.png"), dpi=150); plt.close()

    plt.figure(figsize=(6.5, 4))
    plt.plot(pooled.months_since_start, pooled.logo_retention * 100, marker="o", label="customers (logo)", color=COLORS["forecast"])
    plt.plot(pooled.months_since_start, pooled.revenue_retention * 100, marker="o", label="revenue", color=COLORS["alt"])
    plt.axhline(100, color="k", lw=0.6, ls="--"); plt.ylim(0, 110)
    plt.xlabel("Months since first payment"); plt.ylabel("% of starting"); plt.title("Paying-customer cohort retention")
    plt.legend(); plt.tight_layout(); plt.savefig(os.path.join(fdir, "cohort_retention_curve.png"), dpi=150); plt.close()


if __name__ == "__main__":
    main()
