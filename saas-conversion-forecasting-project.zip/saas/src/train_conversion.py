"""
Free-to-paid conversion model.

Question : of the users still on the free plan at day 14, who will upgrade in days 15-44?
Features : first-14-day usage + static attributes only (no leakage; see sql/04_conversion_dataset.sql)
Split    : time-based by signup month  (train <= 2025-06, validation 2025-07..2025-12, test 2026-01..2026-05)
Models   : Logistic Regression (baseline) and XGBoost
           (falls back to scikit-learn HistGradientBoosting if xgboost is not installed; the model that
            actually ran is written into outputs/tables/conversion_model_metrics.csv)
Metrics  : ROC-AUC, PR-AUC, lift / capture in the top decile (the base rate is only ~3.5%, so accuracy is useless)

    python src/train_conversion.py --tables outputs/tables --figures outputs/figures
"""
import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, brier_score_loss, log_loss, roc_auc_score, roc_curve)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

try:
    from xgboost import XGBClassifier
    HAS_XGB = True
except ImportError:
    HAS_XGB = False

COUNT_COLS = ["sessions_14d", "active_days_14d", "projects_created_14d", "collaborators_invited_14d",
              "features_used_14d", "integrations_connected_14d", "support_tickets_14d"]
BIN_COLS = ["hit_usage_limit_14d", "onboarding_completed"]
NUM_COLS = COUNT_COLS + BIN_COLS
CAT_COLS = ["channel", "company_size", "region"]
FEATS = NUM_COLS + CAT_COLS
SEED = 42


def top_decile(y, p):
    k = max(int(len(y) * 0.10), 1)
    idx = np.argsort(-p)[:k]
    cap = y[idx].sum() / y.sum()
    lift = y[idx].mean() / y.mean()
    return float(cap), float(lift)


def evaluate(name, y, p):
    cap, lift = top_decile(y, p)
    return {"model": name, "roc_auc": roc_auc_score(y, p), "pr_auc": average_precision_score(y, p),
            "base_rate": float(y.mean()), "top_decile_capture": cap, "top_decile_lift": lift,
            "log_loss": log_loss(y, p), "brier": brier_score_loss(y, p)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tables", default="outputs/tables")
    ap.add_argument("--figures", default="outputs/figures")
    args = ap.parse_args()
    os.makedirs(args.figures, exist_ok=True)

    df = pd.read_csv(os.path.join(args.tables, "conversion_dataset.csv"))
    y_col = "converted_next_30d"
    train = df[df.signup_month <= "2025-06"]
    val = df[(df.signup_month >= "2025-07") & (df.signup_month <= "2025-12")]
    test = df[df.signup_month >= "2026-01"]
    print(f"train={len(train):,} (conv {train[y_col].mean():.3%})  val={len(val):,}  "
          f"test={len(test):,} (conv {test[y_col].mean():.3%}, positives={int(test[y_col].sum())})")

    log = FunctionTransformer(np.log1p, feature_names_out="one-to-one")
    pre_lr = ColumnTransformer([
        ("cnt", Pipeline([("log", log), ("sc", StandardScaler())]), COUNT_COLS),
        ("bin", "passthrough", BIN_COLS),
        ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), CAT_COLS)])
    pre_tree = ColumnTransformer([
        ("num", "passthrough", NUM_COLS),
        ("cat", OneHotEncoder(handle_unknown="ignore"), CAT_COLS)])

    lr = Pipeline([("pre", pre_lr), ("clf", LogisticRegression(max_iter=3000, C=1.0))])
    lr.fit(train[FEATS], train[y_col])

    if HAS_XGB:
        name = "XGBoost"
        pre_tree.fit(train[FEATS])
        clf = XGBClassifier(n_estimators=800, max_depth=3, learning_rate=0.03, subsample=0.8, colsample_bytree=0.8,
                            min_child_weight=5, eval_metric="logloss", early_stopping_rounds=40,
                            random_state=SEED, n_jobs=-1)
        clf.fit(pre_tree.transform(train[FEATS]), train[y_col],
                eval_set=[(pre_tree.transform(val[FEATS]), val[y_col])], verbose=False)
        gb = Pipeline([("pre", pre_tree), ("clf", clf)])
    else:
        name = "HistGradientBoosting (XGBoost fallback)"
        print("WARNING: xgboost not installed -> using scikit-learn HistGradientBoosting. Install xgboost and "
              "re-run to get true XGBoost results.")
        gb = Pipeline([("pre", pre_tree),
                       ("clf", HistGradientBoostingClassifier(max_iter=400, learning_rate=0.04, max_depth=3,
                                                              min_samples_leaf=40, l2_regularization=1.0,
                                                              early_stopping=True, validation_fraction=0.15,
                                                              random_state=SEED))])
        gb.fit(train[FEATS], train[y_col])

    probs, rows = {}, []
    for mname, model in [("Logistic Regression", lr), (name, gb)]:
        p = model.predict_proba(test[FEATS])[:, 1]
        probs[mname] = p
        rows.append(evaluate(mname, test[y_col].to_numpy(), p))
    res = pd.DataFrame(rows)
    res.to_csv(os.path.join(args.tables, "conversion_model_metrics.csv"), index=False)
    print("\nTEST METRICS\n", res.round(4).to_string(index=False))

    # ---- drivers: logistic odds ratios per 1 SD (interpretable) + permutation importance (model-agnostic)
    names = lr.named_steps["pre"].get_feature_names_out()
    coef = lr.named_steps["clf"].coef_[0]
    orr = pd.DataFrame({"feature": names, "coefficient": coef, "odds_ratio": np.exp(coef)})
    orr["feature"] = orr.feature.str.replace(r"^(cnt|bin|cat)__", "", regex=True)
    orr = orr.reindex(orr.coefficient.abs().sort_values(ascending=False).index)
    orr.to_csv(os.path.join(args.tables, "conversion_odds_ratios.csv"), index=False)

    samp = test.sample(min(len(test), 15_000), random_state=SEED)
    pi = permutation_importance(gb, samp[FEATS], samp[y_col], scoring="roc_auc", n_repeats=5,
                                random_state=SEED, n_jobs=1)
    imp = pd.DataFrame({"feature": FEATS, "auc_drop": pi.importances_mean}).sort_values("auc_drop", ascending=False)
    imp.to_csv(os.path.join(args.tables, "conversion_feature_importance.csv"), index=False)
    print("\nTOP DRIVERS (permutation importance)\n", imp.head(7).round(4).to_string(index=False))
    print("\nLOGISTIC ODDS RATIOS (per 1 SD for log-counts)\n", orr.head(8).round(3).to_string(index=False))

    # ---- scored users, deciles, calibration
    best = name
    out = test[["user_id", "signup_month", "channel", "company_size", "region"]].copy()
    out["conversion_prob"] = probs[best]
    out["actual_converted"] = test[y_col].to_numpy()
    out["decile"] = pd.qcut(out.conversion_prob.rank(method="first", ascending=False), 10,
                            labels=list(range(1, 11))).astype(int)
    out.to_csv(os.path.join(args.tables, "conversion_scores.csv"), index=False)
    dec = out.groupby("decile").agg(users=("user_id", "size"), avg_predicted=("conversion_prob", "mean"),
                                    actual_rate=("actual_converted", "mean"),
                                    conversions=("actual_converted", "sum")).reset_index()
    dec["cum_capture"] = dec.conversions.cumsum() / dec.conversions.sum()
    dec.to_csv(os.path.join(args.tables, "conversion_deciles.csv"), index=False)
    print("\nDECILES (1 = highest predicted)\n", dec.round(4).to_string(index=False))

    # ---- figures
    plt.figure(figsize=(5.5, 5))
    for mname, p in probs.items():
        fpr, tpr, _ = roc_curve(test[y_col], p)
        plt.plot(fpr, tpr, label=f"{mname} (AUC {roc_auc_score(test[y_col], p):.3f})")
    plt.plot([0, 1], [0, 1], "k--", lw=1)
    plt.xlabel("False positive rate"); plt.ylabel("True positive rate")
    plt.title("Conversion model ROC (test: 2026 signups)"); plt.legend(loc="lower right"); plt.tight_layout()
    plt.savefig(os.path.join(args.figures, "conversion_roc.png"), dpi=150); plt.close()

    plt.figure(figsize=(6.5, 4))
    plt.bar(dec.decile, dec.actual_rate * 100, color="#5B6CFF", label="actual")
    plt.plot(dec.decile, dec.avg_predicted * 100, "o-", color="#C0392B", label="predicted")
    plt.axhline(test[y_col].mean() * 100, color="k", ls="--", lw=1, label="base rate")
    plt.xlabel("Predicted-probability decile (1 = highest)"); plt.ylabel("Conversion rate, %")
    plt.title("Calibration and lift by decile"); plt.legend(); plt.tight_layout()
    plt.savefig(os.path.join(args.figures, "conversion_deciles.png"), dpi=150); plt.close()

    top = imp.head(8).iloc[::-1]
    plt.figure(figsize=(6.5, 4))
    plt.barh(top.feature, top.auc_drop, color="#16A085")
    plt.xlabel("Drop in ROC-AUC when shuffled"); plt.title("What drives free-to-paid conversion")
    plt.tight_layout(); plt.savefig(os.path.join(args.figures, "conversion_drivers.png"), dpi=150); plt.close()
    print("\nSaved tables and figures.")


if __name__ == "__main__":
    main()
