"""
Simulated product-led SaaS business (Jan 2023 - Jun 2026): free signups -> early product usage ->
free-to-paid conversion -> monthly subscriptions (churn, upgrades) -> invoices / MRR.

IMPORTANT: this data is SIMULATED. Conversion drivers, price points, churn and seasonality are explicit
assumptions, not measurements of a real company. Say so in your README / interviews.

    python src/simulate_saas.py --out data
Outputs: users.csv, usage_14d.csv, subscriptions.csv, invoices.csv
"""
import argparse
import os

import numpy as np
import pandas as pd

START = pd.Timestamp("2023-01-01")
END = pd.Timestamp("2026-06-30")
N_DAYS = (END - START).days + 1                    # 1,277 days
N_MONTHS = 42
PRICE = {"Starter": 15, "Pro": 39, "Team": 99}
PLANS = ["Starter", "Pro", "Team"]
CHURN = {"Starter": 0.070, "Pro": 0.045, "Team": 0.025}        # base monthly hazard
UPGRADE = {"Starter": 0.020, "Pro": 0.012, "Team": 0.0}        # monthly upgrade prob
TENURE_MULT = {0: 1.8, 1: 1.4, 2: 1.2}                         # early-life churn is higher
BASE_SIGNUPS = 48.0
INTERCEPT = -3.55                                              # tunes overall conversion rate


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def simulate_signups(rng):
    d = np.arange(N_DAYS)
    dates = START + pd.to_timedelta(d, unit="D")
    doy = dates.dayofyear.to_numpy()
    lam = BASE_SIGNUPS * (1 + 1.8 * d / N_DAYS)                                 # business growth
    lam = lam * (1 + 0.16 * np.cos(2 * np.pi * (doy - 15) / 365)                # January peak
                 + 0.10 * np.cos(2 * np.pi * (doy - 255) / 365))                # September peak
    lam = lam * np.where(dates.dayofweek >= 5, 0.55, 1.0)                       # weekends are quiet
    for s, e in [("2024-11-04", "2024-11-24"), ("2025-03-10", "2025-03-24"), ("2026-02-02", "2026-02-16")]:
        lam = lam * np.where((dates >= s) & (dates <= e), 1.35, 1.0)            # marketing campaigns
    counts = rng.poisson(lam)
    return np.repeat(d, counts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data")
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    day_idx = simulate_signups(rng)
    n = len(day_idx)
    signup_date = START + pd.to_timedelta(day_idx, unit="D")
    channel = rng.choice(["organic", "paid", "referral", "partner"], n, p=[.42, .25, .18, .15])
    size = rng.choice(["solo", "small", "mid"], n, p=[.55, .30, .15])
    region = rng.choice(["NA", "EU", "APAC", "LATAM"], n, p=[.45, .30, .17, .08])

    # latent purchase intent (never exported)
    z = (rng.normal(0, 1, n) + np.select([channel == "referral", channel == "partner", channel == "paid"],
                                         [0.3, 0.4, -0.2], 0.0)
         + np.select([size == "small", size == "mid"], [0.3, 0.6], 0.0))

    # ---------------- first-14-day usage ----------------
    active_days = 1 + rng.binomial(13, sigmoid(-1.4 + 0.8 * z))
    sessions = active_days + rng.poisson(active_days * np.exp(0.3 * z))
    projects = rng.poisson(np.exp(-0.3 + 0.5 * z) * np.sqrt(active_days))
    invited = rng.poisson(np.exp(-1.6 + 0.6 * z + 0.5 * (size != "solo")))
    features = 1 + rng.binomial(5, sigmoid(-0.5 + 0.7 * z))
    integrations = rng.poisson(np.exp(-2.0 + 0.5 * z))
    hit_limit = (rng.random(n) < sigmoid(-1.5 + 0.8 * z + 0.3 * np.log1p(projects))).astype(int)
    tickets = rng.poisson(0.08, n)
    onboarded = (rng.random(n) < sigmoid(-0.2 + 0.9 * z)).astype(int)

    # ---------------- conversion ----------------
    logit = (INTERCEPT + 0.45 * z + 0.9 * hit_limit + 0.5 * (invited > 0) + 0.15 * (integrations > 0)
             + 0.3 * (size == "mid"))
    converts = rng.random(n) < sigmoid(logit)
    delay = np.clip(rng.lognormal(np.log(22), 0.8, n), 1, 200).astype(int)
    conv_day = day_idx + delay
    converts &= conv_day <= N_DAYS - 1                                            # right-censor at data end

    users = pd.DataFrame({
        "user_id": np.arange(1, n + 1), "signup_date": signup_date.strftime("%Y-%m-%d"),
        "signup_month": signup_date.strftime("%Y-%m"), "signup_day_idx": day_idx,
        "channel": channel, "company_size": size, "region": region})
    usage = pd.DataFrame({
        "user_id": users.user_id, "sessions_14d": sessions, "active_days_14d": active_days,
        "projects_created_14d": projects, "collaborators_invited_14d": invited, "features_used_14d": features,
        "integrations_connected_14d": integrations, "hit_usage_limit_14d": hit_limit,
        "support_tickets_14d": tickets, "onboarding_completed": onboarded})

    # ---------------- subscriptions and invoices ----------------
    cu = np.flatnonzero(converts)
    conv_date = START + pd.to_timedelta(conv_day[cu], unit="D")
    start_m = ((conv_date.year - 2023) * 12 + conv_date.month - 1).to_numpy()
    p_plan = np.where((size[cu] == "solo")[:, None], [.70, .28, .02],
                      np.where((size[cu] == "small")[:, None], [.35, .55, .10], [.12, .50, .38]))
    plan = (rng.random(len(cu))[:, None] > np.cumsum(p_plan, axis=1)).sum(1)       # 0,1,2
    zc = z[cu]
    active = np.ones(len(cu), bool)
    inv = []
    for m in range(N_MONTHS):
        live = active & (start_m <= m)
        if not live.any():
            continue
        idx = np.flatnonzero(live)
        inv.append(pd.DataFrame({"user_id": users.user_id.to_numpy()[cu[idx]], "month_idx": m,
                                 "plan": np.array(PLANS)[plan[idx]],
                                 "amount": np.array([PRICE[p] for p in PLANS])[plan[idx]]}))
        tenure = m - start_m[idx]
        base = np.array([CHURN[p] for p in PLANS])[plan[idx]]
        mult = np.array([TENURE_MULT.get(t, 1.0) for t in tenure])
        churned = rng.random(len(idx)) < np.clip(base * mult * np.exp(-0.25 * zc[idx]), 0, 0.9)
        active[idx[churned]] = False
        up = (~churned) & (plan[idx] < 2) & (rng.random(len(idx)) <
              np.array([UPGRADE[p] for p in PLANS])[plan[idx]] * np.exp(0.2 * zc[idx]))
        plan[idx[up]] += 1
    invoices = pd.concat(inv, ignore_index=True)
    invoices["invoice_month"] = [(START + pd.DateOffset(months=int(m))).strftime("%Y-%m") for m in invoices.month_idx]
    invoices.insert(0, "invoice_id", np.arange(1, len(invoices) + 1))

    first = invoices.sort_values("month_idx").groupby("user_id").agg(
        initial_plan=("plan", "first"), final_plan=("plan", "last"), last_month=("month_idx", "max"))
    subs = pd.DataFrame({"user_id": users.user_id.to_numpy()[cu], "conversion_date": conv_date.strftime("%Y-%m-%d"),
                         "days_to_convert": delay[cu], "start_month_idx": start_m}).set_index("user_id").join(first)
    subs["status"] = np.where(subs.last_month == N_MONTHS - 1, "active", "churned")
    subs["end_month_idx"] = np.where(subs.status == "churned", subs.last_month, np.nan)
    subs = subs.drop(columns="last_month").reset_index()

    users.to_csv(os.path.join(args.out, "users.csv"), index=False)
    usage.to_csv(os.path.join(args.out, "usage_14d.csv"), index=False)
    subs.to_csv(os.path.join(args.out, "subscriptions.csv"), index=False)
    invoices.to_csv(os.path.join(args.out, "invoices.csv"), index=False)
    mrr_last = invoices[invoices.month_idx == N_MONTHS - 1].amount.sum()
    print(f"users={n:,} paying_ever={len(subs):,} ({len(subs)/n:.1%}) invoices={len(invoices):,} "
          f"active_subs={int((subs.status=='active').sum()):,} final_MRR=${mrr_last:,.0f}")


if __name__ == "__main__":
    main()
