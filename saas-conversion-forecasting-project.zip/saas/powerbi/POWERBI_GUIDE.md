# Power BI dashboard guide

A `.pbix` can't be generated outside Power BI Desktop, so this gives the exact data model, measures and layout
(about 30-45 minutes to build). All inputs are in `outputs/tables/`.

## 1. Load (Get Data -> Text/CSV)
| Table | File | Grain |
|---|---|---|
| revenue_kpis | revenue_kpis.csv | month: MRR, new / expansion / churned MRR, churn, expansion, NRR, growth |
| monthly_revenue | monthly_revenue.csv | month: MRR, paying customers, ARPA |
| mrr_forecast | mrr_forecast.csv | forecast month: forecast_mrr, lower_80, upper_80 |
| forecast_all_models | forecast_all_models.csv | forecast month x model (wide) |
| forecast_backtest_summary | forecast_backtest_summary.csv | model comparison (MAPE, MAE, by horizon) |
| scenarios | scenarios.csv | scenario: Dec 2026 MRR and deltas |
| conversion_funnel | conversion_funnel.csv | signup month: signups, onboarding, conversion rates |
| driver_lift | driver_lift.csv | behaviour x yes/no conversion rate |
| conversion_model_metrics | conversion_model_metrics.csv | model comparison |
| conversion_feature_importance | conversion_feature_importance.csv | permutation importance |
| conversion_deciles | conversion_deciles.csv | decile: predicted vs actual rate, cumulative capture |
| conversion_scores | conversion_scores.csv | scored 2026 users (decile, probability) |
| cohort_retention_curve | cohort_retention_curve.csv | months since start: logo and revenue retention |

Relationships are optional: tables are pre-aggregated. Relate `conversion_scores[decile]` to
`conversion_deciles[decile]` if you want slicers to cross-filter.

## 2. DAX measures (create in a `_Measures` table)
```DAX
Latest MRR       = CALCULATE ( MAX ( revenue_kpis[mrr] ), TOPN ( 1, revenue_kpis, revenue_kpis[month_idx], DESC ) )
MRR YoY %        = DIVIDE ( [Latest MRR],
                     CALCULATE ( MAX ( revenue_kpis[mrr] ), revenue_kpis[month_idx] = MAX ( revenue_kpis[month_idx] ) - 12 ) ) - 1
Avg Churn 6M     = AVERAGEX ( TOPN ( 6, revenue_kpis, revenue_kpis[month_idx], DESC ), revenue_kpis[gross_mrr_churn_rate] )
Avg NRR 6M       = AVERAGEX ( TOPN ( 6, revenue_kpis, revenue_kpis[month_idx], DESC ), revenue_kpis[nrr_monthly] )
Forecast Dec MRR = CALCULATE ( MAX ( mrr_forecast[forecast_mrr] ), TOPN ( 1, mrr_forecast, mrr_forecast[month_idx], DESC ) )
Forecast Low     = CALCULATE ( MAX ( mrr_forecast[lower_80] ),    TOPN ( 1, mrr_forecast, mrr_forecast[month_idx], DESC ) )
Forecast High    = CALCULATE ( MAX ( mrr_forecast[upper_80] ),    TOPN ( 1, mrr_forecast, mrr_forecast[month_idx], DESC ) )
Top Decile Capture = CALCULATE ( MAX ( conversion_deciles[cum_capture] ), conversion_deciles[decile] = 1 )
Top Decile Lift    = DIVIDE ( CALCULATE ( MAX ( conversion_deciles[actual_rate] ), conversion_deciles[decile] = 1 ),
                              AVERAGE ( conversion_scores[actual_converted] ) )
```
Format rates as `0.0%` and currency as `$#,0`. Confidence-interval and model-metric numbers come from the Python
tables, not DAX.

## 3. Pages
1. **Executive summary** - cards: Latest MRR, MRR YoY %, paying customers, Avg NRR 6M, Avg Churn 6M; line chart of
   `revenue_kpis[mrr]` by month with the forecast and its interval (line chart with `mrr_forecast` band) as a second layer.
2. **Revenue bridge** - stacked column of `new_mrr`, `expansion_mrr`, `-churned_mrr` by month; line of `nrr_monthly`;
   `cohort_retention_curve` (logo vs revenue retention).
3. **Conversion funnel** - signups, onboarding rate, 30-day conversion by `signup_month` (**drop the last two
   months**: their conversion window is incomplete); bar chart of `driver_lift` (conversion rate yes vs no per behaviour).
4. **Conversion model** - cards from `conversion_model_metrics` (ROC-AUC, PR-AUC, top-decile lift);
   predicted-vs-actual by decile; `cum_capture` gains curve; `conversion_feature_importance` bars;
   table of top-decile users (`conversion_scores`, decile = 1) filtered by channel / company size.
5. **Forecast & scenarios** - `forecast_backtest_summary` (MAPE by model), `forecast_all_models` line comparison,
   `scenarios` bar chart of Dec 2026 MRR vs baseline; note the model-disagreement range.

## 4. Storytelling tips
Titles that state the insight ("Hitting a usage limit triples upgrade odds", "Growth is acquisition-driven: NRR
is 98% per month"), a visible "Simulated data" footnote, and uncertainty (intervals, backtest MAPE) beside every forecast.
