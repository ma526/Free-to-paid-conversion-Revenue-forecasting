-- Paying-customer cohorts: logo and revenue retention by months since first payment
WITH first_pay AS (
    SELECT user_id, MIN(month_idx) AS start_idx FROM invoices GROUP BY user_id
)
SELECT f.start_idx AS cohort_idx,
       i.month_idx - f.start_idx AS months_since_start,
       COUNT(DISTINCT i.user_id)  AS active_customers,
       SUM(i.amount)              AS cohort_mrr
FROM invoices i
JOIN first_pay f ON i.user_id = f.user_id
GROUP BY f.start_idx, i.month_idx - f.start_idx
ORDER BY f.start_idx, months_since_start
