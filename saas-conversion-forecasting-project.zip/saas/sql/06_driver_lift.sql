-- Simple conversion lift for key early behaviours (descriptive, not causal)
SELECT 'hit_usage_limit' AS behaviour,
       hit_usage_limit_14d AS has_behaviour, COUNT(*) AS users, AVG(converted_next_30d * 1.0) AS conversion_rate
FROM conversion_dataset GROUP BY hit_usage_limit_14d
UNION ALL
SELECT 'invited_collaborator', CASE WHEN collaborators_invited_14d > 0 THEN 1 ELSE 0 END, COUNT(*), AVG(converted_next_30d * 1.0)
FROM conversion_dataset GROUP BY CASE WHEN collaborators_invited_14d > 0 THEN 1 ELSE 0 END
UNION ALL
SELECT 'connected_integration', CASE WHEN integrations_connected_14d > 0 THEN 1 ELSE 0 END, COUNT(*), AVG(converted_next_30d * 1.0)
FROM conversion_dataset GROUP BY CASE WHEN integrations_connected_14d > 0 THEN 1 ELSE 0 END
UNION ALL
SELECT 'completed_onboarding', onboarding_completed, COUNT(*), AVG(converted_next_30d * 1.0)
FROM conversion_dataset GROUP BY onboarding_completed
UNION ALL
SELECT 'active_4plus_days', CASE WHEN active_days_14d >= 4 THEN 1 ELSE 0 END, COUNT(*), AVG(converted_next_30d * 1.0)
FROM conversion_dataset GROUP BY CASE WHEN active_days_14d >= 4 THEN 1 ELSE 0 END
