-- MRR bridge: new, expansion (upgrades) and churned MRR per month
WITH inv AS (
    SELECT user_id, month_idx, amount,
           LAG(amount) OVER (PARTITION BY user_id ORDER BY month_idx)       AS prev_amount,
           ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY month_idx)      AS rn,
           ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY month_idx DESC) AS rn_desc
    FROM invoices
),
mv AS (
    SELECT month_idx,
           SUM(CASE WHEN rn = 1 THEN amount ELSE 0 END) AS new_mrr,
           SUM(CASE WHEN rn > 1 AND amount > prev_amount THEN amount - prev_amount ELSE 0 END) AS expansion_mrr,
           SUM(CASE WHEN rn = 1 THEN 1 ELSE 0 END) AS new_customers
    FROM inv GROUP BY month_idx
),
ch AS (
    SELECT month_idx + 1 AS month_idx, SUM(amount) AS churned_mrr, COUNT(*) AS churned_customers
    FROM inv WHERE rn_desc = 1 GROUP BY month_idx + 1
)
SELECT m.month_idx, m.invoice_month, m.mrr, m.paying_customers,
       COALESCE(mv.new_mrr, 0)            AS new_mrr,
       COALESCE(mv.expansion_mrr, 0)      AS expansion_mrr,
       COALESCE(ch.churned_mrr, 0)        AS churned_mrr,
       COALESCE(mv.new_customers, 0)      AS new_customers,
       COALESCE(ch.churned_customers, 0)  AS churned_customers
FROM monthly_revenue m
LEFT JOIN mv ON m.month_idx = mv.month_idx
LEFT JOIN ch ON m.month_idx = ch.month_idx
ORDER BY m.month_idx
