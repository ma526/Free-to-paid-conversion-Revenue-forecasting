-- Modelling table. Prediction time = day 14 after signup.
--   population : users still on the free plan at day 14 (not converted before day 15)
--   target     : converts to paid between day 15 and day 44
--   features   : first-14-day usage + static attributes only (no leakage)
--   only users whose full 45-day outcome window is observed are kept
SELECT u.user_id, u.signup_month, u.signup_day_idx, u.channel, u.company_size, u.region,
       f.sessions_14d, f.active_days_14d, f.projects_created_14d, f.collaborators_invited_14d,
       f.features_used_14d, f.integrations_connected_14d, f.hit_usage_limit_14d,
       f.support_tickets_14d, f.onboarding_completed,
       CASE WHEN s.days_to_convert BETWEEN 15 AND 44 THEN 1 ELSE 0 END AS converted_next_30d
FROM users u
JOIN usage_14d f ON u.user_id = f.user_id
LEFT JOIN subscriptions s ON u.user_id = s.user_id
WHERE (s.days_to_convert IS NULL OR s.days_to_convert >= 15)
  AND u.signup_day_idx + 44 <= (SELECT MAX(signup_day_idx) FROM users)
