-- MRR, paying customers and ARPA per month
SELECT month_idx, invoice_month,
       SUM(amount)                 AS mrr,
       COUNT(DISTINCT user_id)     AS paying_customers,
       SUM(amount) * 1.0 / COUNT(DISTINCT user_id) AS arpa
FROM invoices
GROUP BY month_idx, invoice_month
ORDER BY month_idx
