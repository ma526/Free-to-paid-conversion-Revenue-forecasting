-- Monthly signup cohorts: activation and free-to-paid conversion (integer day columns keep this portable)
SELECT u.signup_month,
       COUNT(*)                                                                  AS signups,
       SUM(f.onboarding_completed)                                               AS onboarded,
       SUM(CASE WHEN s.days_to_convert IS NOT NULL THEN 1 ELSE 0 END)            AS converted_ever,
       SUM(CASE WHEN s.days_to_convert <= 30 THEN 1 ELSE 0 END)                  AS converted_30d,
       AVG(f.onboarding_completed * 1.0)                                         AS onboarding_rate,
       AVG(CASE WHEN s.days_to_convert <= 30 THEN 1.0 ELSE 0.0 END)              AS conversion_rate_30d,
       AVG(CASE WHEN s.days_to_convert IS NOT NULL THEN 1.0 ELSE 0.0 END)        AS conversion_rate_ever
FROM users u
JOIN usage_14d f ON u.user_id = f.user_id
LEFT JOIN subscriptions s ON u.user_id = s.user_id
GROUP BY u.signup_month
ORDER BY u.signup_month
